package com.hallbooking.servlet;

import com.hallbooking.util.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/api/halls/*")
public class HallServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        try (Connection c = DB.get()) {
            if ("/availability".equals(req.getPathInfo())) { availability(c, req, res); return; }
            String city = req.getParameter("city");
            boolean hasCity = city != null && !city.isBlank();
            String mc = req.getParameter("minCapacity");
            int minCap = mc == null || mc.isBlank() ? 0 : Integer.parseInt(mc);
            String sql = "SELECT * FROM halls WHERE capacity>=?" + (hasCity ? " AND city=?" : "") + " ORDER BY price_per_hour";
            List<Map<String, Object>> out = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, minCap);
                if (hasCity) ps.setString(2, city);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Map<String, Object> h = new LinkedHashMap<>();
                        h.put("id", rs.getInt("id")); h.put("name", rs.getString("name"));
                        h.put("city", rs.getString("city")); h.put("capacity", rs.getInt("capacity"));
                        h.put("price", rs.getDouble("price_per_hour")); h.put("emoji", rs.getString("emoji"));
                        h.put("description", rs.getString("description")); h.put("amenities", rs.getString("amenities"));
                        out.add(h);
                    }
                }
            }
            Json.send(res, 200, out);
        } catch (Exception e) {
            Json.error(res, 500, "Could not load halls");
        }
    }

    /** Busy time ranges for one hall on one date. */
    private void availability(Connection c, HttpServletRequest req, HttpServletResponse res) throws Exception {
        List<Map<String, String>> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT start_time,end_time FROM bookings WHERE hall_id=? AND event_date=? AND " + DB.ACTIVE + " ORDER BY start_time")) {
            ps.setInt(1, Integer.parseInt(req.getParameter("hallId")));
            ps.setDate(2, java.sql.Date.valueOf(req.getParameter("date")));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(Map.of("start", rs.getString(1).substring(0, 5), "end", rs.getString(2).substring(0, 5)));
            }
        }
        Json.send(res, 200, out);
    }
}
