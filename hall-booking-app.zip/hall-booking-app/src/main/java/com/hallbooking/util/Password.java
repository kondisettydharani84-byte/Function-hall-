package com.hallbooking.util;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/** PBKDF2 password hashing. Stored format: base64(salt):base64(hash). */
public final class Password {
    private static final int ITER = 65536, BITS = 256;

    private static byte[] hash(char[] pw, byte[] salt) throws Exception {
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(new PBEKeySpec(pw, salt, ITER, BITS)).getEncoded();
    }

    public static String create(String pw) throws Exception {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        Base64.Encoder b = Base64.getEncoder();
        return b.encodeToString(salt) + ":" + b.encodeToString(hash(pw.toCharArray(), salt));
    }

    public static boolean verify(String pw, String stored) throws Exception {
        String[] p = stored.split(":");
        byte[] expected = Base64.getDecoder().decode(p[1]);
        byte[] actual = hash(pw.toCharArray(), Base64.getDecoder().decode(p[0]));
        return MessageDigest.isEqual(expected, actual);
    }

    private Password() {}
}
