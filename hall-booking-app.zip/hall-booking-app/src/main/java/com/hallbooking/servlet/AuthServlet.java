package com.hallbooking.servlet;

import com.google.gson.JsonObject;
import com.hallbooking.util.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.Map;

@WebServlet("/api/auth/*")
public class AuthServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("uid") == null) { Json.send(res, 200, Map.of("user", "")); return; }
        Json.send(res, 200, Map.of("user", Map.of("id", s.getAttribute("uid"), "name", s.getAttribute("name"))));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        try {
            if (path.equals("/logout")) {
                HttpSession s = req.getSession(false);
                if (s != null) s.invalidate();
                Json.send(res, 200, Map.of("ok", true));
                return;
            }
            JsonObject b = Json.body(req);
            String email = Json.str(b, "email").toLowerCase(), pw = Json.str(b, "password");
            if (path.equals("/register")) register(req, res, Json.str(b, "name"), email, pw);
            else if (path.equals("/login")) login(req, res, email, pw);
            else Json.error(res, 404, "Unknown action");
        } catch (Exception e) {
            Json.error(res, 400, "Bad request");
        }
    }

    private void register(HttpServletRequest req, HttpServletResponse res, String name, String email, String pw) throws Exception {
        if (name.length() < 2 || !email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$") || pw.length() < 8) {
            Json.error(res, 400, "Enter a name, a valid email and a password of 8+ characters");
            return;
        }
        try (Connection c = DB.get();
             PreparedStatement ps = c.prepareStatement("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name); ps.setString(2, email); ps.setString(3, Password.create(pw));
            ps.executeUpdate();
            try (ResultSet k = ps.getGeneratedKeys()) { k.next(); startSession(req, k.getInt(1), name); }
            Json.send(res, 201, Map.of("user", Map.of("name", name)));
        } catch (SQLIntegrityConstraintViolationException dup) {
            Json.error(res, 409, "Email already registered");
        }
    }

    private void login(HttpServletRequest req, HttpServletResponse res, String email, String pw) throws Exception {
        try (Connection c = DB.get();
             PreparedStatement ps = c.prepareStatement("SELECT id,name,password_hash FROM users WHERE email=?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next() || !Password.verify(pw, rs.getString("password_hash"))) {
                    Json.error(res, 401, "Wrong email or password");
                    return;
                }
                startSession(req, rs.getInt("id"), rs.getString("name"));
                Json.send(res, 200, Map.of("user", Map.of("name", rs.getString("name"))));
            }
        }
    }

    private void startSession(HttpServletRequest req, int id, String name) {
        HttpSession old = req.getSession(false);
        if (old != null) old.invalidate();          // prevent session fixation
        HttpSession s = req.getSession(true);
        s.setAttribute("uid", id);
        s.setAttribute("name", name);
    }
}
