# 🐝 HallHive – Online Hall Booking System

A complete hall booking web app: **HTML/CSS/JavaScript** front end, **Java Servlets + JDBC** back end, **MySQL** database.

## Features
- Register / log in (PBKDF2 salted password hashing, session login)
- Search halls by city and capacity
- **Live availability**: booked time ranges are shown for the chosen date
- **Live price quote** with weekend surcharge (+20%) and **coupon codes** (`WELCOME10`, `FESTIVE20`)
- **Double-booking protection** (database transaction + row lock)
- **15-minute slot hold** with countdown while you pay
- **Payment methods**: Card (Luhn check, expiry, CVV), UPI, Net banking, Pay at venue
- Cancel with automatic (demo) refund, printable **receipt with unique visual code**
- Dark mode

## Payment note
The payment step is a **demo gateway** (no real money). Only the card's last 4 digits are stored.
Demo cards: `4242 4242 4242 4242` succeeds; any card ending `0002` is declined.
For real payments, replace the gateway logic in `PaymentServlet` with Razorpay, Stripe or PayPal server-side APIs.

## Project structure
```
hall-booking-app/
├── pom.xml
├── database/schema.sql
└── src/main/
    ├── java/com/hallbooking/
    │   ├── util/    DB.java, Json.java, Password.java, Pricing.java
    │   └── servlet/ AuthServlet.java, HallServlet.java, BookingServlet.java, PaymentServlet.java
    ├── resources/db.properties.example
    └── webapp/      index.html, css/style.css, js/app.js
```

## Run it
Requirements: JDK 17+, Maven, MySQL 8+, **Apache Tomcat 9** (uses `javax.servlet`).

1. Create the database: `mysql -u root -p < database/schema.sql`
2. Copy `src/main/resources/db.properties.example` to `db.properties` and set your MySQL password
   (or set env vars `DB_URL`, `DB_USER`, `DB_PASSWORD`).
3. Build: `mvn clean package`
4. Copy `target/hall-booking.war` into Tomcat's `webapps/` folder and start Tomcat.
5. Open http://localhost:8080/hall-booking/

## Upload to GitHub
```
git init
git add .
git commit -m "HallHive hall booking system"
git branch -M main
git remote add origin https://github.com/<your-username>/hall-booking-app.git
git push -u origin main
```
(`db.properties` is git-ignored so your password is never uploaded.)
