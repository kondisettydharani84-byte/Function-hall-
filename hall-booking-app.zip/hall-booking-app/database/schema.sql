-- HallHive schema (MySQL 8+)
CREATE DATABASE IF NOT EXISTS hall_booking CHARACTER SET utf8mb4;
USE hall_booking;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(200) NOT NULL,          -- salt:PBKDF2 hash (Base64)
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE halls (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  city VARCHAR(60) NOT NULL,
  capacity INT NOT NULL,
  price_per_hour DECIMAL(10,2) NOT NULL,
  emoji VARCHAR(8) NOT NULL,
  description VARCHAR(255),
  amenities VARCHAR(255)
);

CREATE TABLE coupons (
  code VARCHAR(20) PRIMARY KEY,
  percent_off INT NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1
);

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ref_code VARCHAR(12) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  hall_id INT NOT NULL,
  event_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  guests INT NOT NULL,
  event_type VARCHAR(40) NOT NULL,
  coupon_code VARCHAR(20),
  total_amount DECIMAL(10,2) NOT NULL,
  status ENUM('PENDING','CONFIRMED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (hall_id) REFERENCES halls(id),
  INDEX idx_slot (hall_id, event_date)
);

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  method ENUM('CARD','UPI','NETBANKING','VENUE') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  status ENUM('SUCCESS','PAY_AT_VENUE','REFUNDED') NOT NULL,
  txn_id VARCHAR(30) NOT NULL,
  card_last4 CHAR(4),                            -- never store full card number / CVV
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

INSERT INTO halls (name, city, capacity, price_per_hour, emoji, description, amenities) VALUES
('Royal Orchid Banquet','Chennai',400,5000,'👑','Grand banquet hall with stage and chandeliers','AC, Stage, Parking, Catering'),
('Lotus Garden Lawn','Bengaluru',250,3500,'🌸','Open-air lawn for weddings and receptions','Lawn, Lights, Parking, DJ'),
('Skyline Conference Hall','Mumbai',120,2500,'🏙️','Modern hall for meetings and seminars','AC, Projector, Wi-Fi, Mic'),
('Pearl Party Studio','Hyderabad',60,1500,'🎉','Cozy space for birthdays and small parties','AC, Sound, Decor, Wi-Fi'),
('Heritage Marriage Palace','Chennai',800,9000,'🏰','Traditional palace hall for large weddings','AC, Dining, Rooms, Parking');

INSERT INTO coupons (code, percent_off) VALUES ('WELCOME10',10),('FESTIVE20',20);
