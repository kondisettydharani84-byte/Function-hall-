const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => '₹' + Number(n).toLocaleString('en-IN');
let user = null, hall = null, booking = null, timer = null, method = 'CARD', regMode = false;

async function api(path, verb = 'GET', body) {
  const r = await fetch('api/' + path, {
    method: verb, headers: body ? {'Content-Type': 'application/json'} : {},
    body: body ? JSON.stringify(body) : undefined
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Something went wrong');
  return d;
}

function toast(m) {
  const t = $('#toast'); t.textContent = m; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

document.addEventListener('click', e => {
  if (e.target.classList.contains('close')) { e.target.closest('dialog').close(); }
});

/* ---------- theme ---------- */
function applyTheme(t) { document.documentElement.dataset.theme = t; try { localStorage.setItem('theme', t); } catch (e) {} }
$('#themeBtn').onclick = () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
try { applyTheme(localStorage.getItem('theme') || 'light'); } catch (e) {}

/* ---------- auth ---------- */
function setUser(u) {
  user = u;
  $('#hello').textContent = u ? 'Hi, ' + u.name : '';
  $('#authBtn').textContent = u ? 'Log out' : 'Log in';
  $('#myBtn').hidden = !u;
}
function openAuth(reg) {
  regMode = !!reg;
  $('#authTitle').textContent = regMode ? 'Create account' : 'Log in';
  $('#aName').hidden = !regMode; $('#aName').required = regMode;
  $('#aGo').textContent = regMode ? 'Sign up' : 'Log in';
  $('#aSwitch').textContent = regMode ? 'Have an account? Log in' : 'New here? Create an account';
  $('#aErr').textContent = ''; $('#authDlg').showModal();
}
$('#aSwitch').onclick = e => { e.preventDefault(); openAuth(!regMode); };
$('#authBtn').onclick = async () => {
  if (user) { await api('auth/logout', 'POST', {}); setUser(null); toast('Logged out'); }
  else openAuth(false);
};
$('#authForm').onsubmit = async e => {
  e.preventDefault();
  try {
    const d = await api('auth/' + (regMode ? 'register' : 'login'), 'POST',
      {name: $('#aName').value, email: $('#aEmail').value, password: $('#aPass').value});
    setUser(d.user); $('#authDlg').close(); toast('Welcome, ' + d.user.name + '!');
  } catch (err) { $('#aErr').textContent = err.message; }
};

/* ---------- halls ---------- */
async function loadHalls() {
  const q = new URLSearchParams({city: $('#fCity').value, minCapacity: $('#fCap').value});
  try {
    const halls = await api('halls?' + q);
    $('#halls').innerHTML = halls.length ? halls.map(h => `
      <div class="card"><div class="emoji">${esc(h.emoji)}</div>
        <h3>${esc(h.name)}</h3><div class="mute">📍 ${esc(h.city)} · 👥 up to ${h.capacity}</div>
        <p>${esc(h.description)}</p>
        <div>${esc(h.amenities).split(',').map(a => `<span class="tag">${a.trim()}</span>`).join('')}</div>
        <p><span class="price">${money(h.price)}</span> <span class="mute">/ hour</span></p>
        <button data-id="${h.id}">Book now</button></div>`).join('') : '<p>No halls match your search.</p>';
    $('#halls').querySelectorAll('button').forEach(b => b.onclick = () => openBook(halls.find(h => h.id == b.dataset.id)));
  } catch (e) { $('#halls').innerHTML = '<p class="err">' + esc(e.message) + '</p>'; }
}
$('#fGo').onclick = loadHalls;

/* ---------- booking ---------- */
const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');

function openBook(h) {
  if (!user) { toast('Please log in to book'); openAuth(false); return; }
  hall = h;
  $('#bTitle').textContent = h.emoji + ' ' + h.name;
  const t = new Date(); $('#bDate').min = ymd(t); t.setDate(t.getDate() + 1); $('#bDate').value = ymd(t);
  $('#bGuests').max = h.capacity; $('#bGuests').value = Math.min(50, h.capacity);
  $('#bErr').textContent = ''; $('#bookDlg').showModal(); refresh();
}

async function refresh() {
  const date = $('#bDate').value; if (!date || !hall) return;
  try {
    const busy = await api(`halls/availability?hallId=${hall.id}&date=${date}`);
    $('#slots').innerHTML = busy.length
      ? busy.map(s => `<span>⛔ ${s.start}–${s.end}</span>`).join('') : '<span class="free">✅ Free all day</span>';
  } catch (e) {}
  try {
    const q = await api('bookings/quote', 'POST', {hallId: hall.id, date, start: $('#bStart').value, end: $('#bEnd').value, coupon: $('#bCoupon').value});
    $('#quote').innerHTML = `${q.hours} h × ${money(hall.price)} = ${money(q.base)}<br>` +
      (q.surcharge ? `Weekend surcharge (+20%): ${money(q.surcharge)}<br>` : '') +
      (q.discount ? `Coupon discount: −${money(q.discount)}<br>` : '') +
      `<b class="total">Total ${money(q.total)}</b>`;
  } catch (e) { $('#quote').textContent = e.message; }
}
['#bDate', '#bStart', '#bEnd'].forEach(s => $(s).addEventListener('input', refresh));
$('#bCoupon').addEventListener('change', refresh);

$('#bookForm').onsubmit = async e => {
  e.preventDefault();
  try {
    const d = await api('bookings', 'POST', {hallId: hall.id, date: $('#bDate').value, start: $('#bStart').value,
      end: $('#bEnd').value, guests: +$('#bGuests').value, eventType: $('#bType').value, coupon: $('#bCoupon').value});
    $('#bookDlg').close();
    openPay({id: d.bookingId, ref: d.ref, hall: hall.name, emoji: hall.emoji, date: $('#bDate').value,
      start: $('#bStart').value, end: $('#bEnd').value, total: d.quote.total, holdLeft: 900});
  } catch (err) { $('#bErr').textContent = err.message; }
};

/* ---------- payment ---------- */
function setMethod(m) {
  method = m;
  document.querySelectorAll('#pTabs button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
  document.querySelectorAll('.pane').forEach(p => p.hidden = p.dataset.m !== m);
  $('#pGo').textContent = m === 'VENUE' ? 'Confirm booking' : 'Pay now';
}
document.querySelectorAll('#pTabs button').forEach(b => b.onclick = () => setMethod(b.dataset.m));
$('#pCard').oninput = e => e.target.value = e.target.value.replace(/\D/g, '').slice(0, 19).replace(/(.{4})/g, '$1 ').trim();
$('#pExp').oninput = e => { let v = e.target.value.replace(/\D/g, '').slice(0, 4); e.target.value = v.length > 2 ? v.slice(0, 2) + '/' + v.slice(2) : v; };

function openPay(b) {
  booking = b; setMethod('CARD'); $('#pErr').textContent = '';
  $('#pAmt').textContent = money(b.total);
  let left = b.holdLeft; clearInterval(timer);
  const tick = () => {
    $('#pTimer').textContent = String(Math.floor(left / 60)).padStart(2, '0') + ':' + String(left % 60).padStart(2, '0');
    if (left-- <= 0) { clearInterval(timer); $('#payDlg').close(); toast('Hold expired. Please book again.'); }
  };
  tick(); timer = setInterval(tick, 1000);
  $('#payDlg').onclose = () => clearInterval(timer);
  $('#payDlg').showModal();
}

$('#payForm').onsubmit = async e => {
  e.preventDefault();
  const body = {bookingId: booking.id, method, cardNumber: $('#pCard').value, expiry: $('#pExp').value,
    cvv: $('#pCvv').value, upiId: $('#pUpi').value, bank: $('#pBank').value};
  $('#pGo').disabled = true;
  try {
    const d = await api('pay', 'POST', body);
    $('#payDlg').close(); $('#pCvv').value = ''; $('#pCard').value = '';
    toast('Booking confirmed 🎉');
    showReceipt({...booking, method, txn: d.txn, status: d.status});
  } catch (err) { $('#pErr').textContent = err.message; }
  $('#pGo').disabled = false;
};

/* ---------- receipt (with a unique visual code) ---------- */
function codeSvg(text) {
  let h = 0; for (const c of text) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  let r = '';
  for (let y = 0; y < 9; y++) for (let x = 0; x < 9; x++) {
    h = (h * 1664525 + 1013904223) >>> 0;
    if ((h >>> 28) & 1) r += `<rect x="${x}" y="${y}" width="1" height="1"/>`;
  }
  return `<svg viewBox="0 0 9 9" fill="currentColor">${r}</svg>`;
}
function showReceipt(b) {
  const label = {CARD: 'Card', UPI: 'UPI', NETBANKING: 'Net banking', VENUE: 'Pay at venue'}[b.method] || '';
  $('#receipt').innerHTML = `<h2>🐝 HallHive Receipt</h2>
    <div>${esc(b.emoji)} <b>${esc(b.hall)}</b></div>
    <div>${esc(b.date)} · ${esc(b.start)}–${esc(b.end)}</div>
    ${codeSvg(b.ref)}
    <div><b>${esc(b.ref)}</b></div>
    <div class="mute">${label}${b.txn ? ' · ' + esc(b.txn) : ''}</div>
    <h3>${b.method === 'VENUE' ? 'To pay at venue: ' : 'Paid: '}${money(b.total)}</h3>`;
  $('#rcDlg').showModal();
}

/* ---------- my bookings ---------- */
let mine = [];
async function loadMine() {
  try {
    mine = await api('bookings');
    $('#myList').innerHTML = mine.length ? mine.map(b => `
      <div class="bk"><b>${esc(b.emoji)} ${esc(b.hall)}</b> <span class="st ${b.status}">${b.status}</span>
        <div class="mute">${esc(b.date)} · ${esc(b.start)}–${esc(b.end)} · ${esc(b.eventType)} · ${b.guests} guests</div>
        <div>${money(b.total)} · ${esc(b.ref)}</div>
        ${b.status === 'PENDING' ? `<button data-a="pay" data-id="${b.id}">Pay now</button>` : ''}
        ${b.status === 'CONFIRMED' ? `<button data-a="rc" data-id="${b.id}">Receipt</button>` : ''}
        ${['PENDING', 'CONFIRMED'].includes(b.status) ? `<button class="ghost" data-a="cx" data-id="${b.id}">Cancel</button>` : ''}
      </div>`).join('') : '<p>No bookings yet.</p>';
  } catch (e) { $('#myList').innerHTML = '<p class="err">' + esc(e.message) + '</p>'; }
}
$('#myBtn').onclick = async () => { await loadMine(); $('#myDlg').showModal(); };
$('#myList').onclick = async e => {
  const a = e.target.dataset.a, b = mine.find(x => x.id == e.target.dataset.id);
  if (!a || !b) return;
  if (a === 'pay') { $('#myDlg').close(); openPay(b); }
  if (a === 'rc') { $('#myDlg').close(); showReceipt(b); }
  if (a === 'cx' && confirm('Cancel this booking? Paid amounts are refunded.')) {
    try { await api('bookings/cancel', 'POST', {bookingId: b.id}); toast('Booking cancelled'); loadMine(); }
    catch (err) { toast(err.message); }
  }
};

/* ---------- start ---------- */
(async () => {
  try { const d = await api('auth'); setUser(d.user || null); } catch (e) {}
  loadHalls();
})();
