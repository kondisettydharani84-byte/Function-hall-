package com.hallbooking.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/** Plain JDBC connection helper. Reads db.properties, env vars override. */
public final class DB {
    /** A booking blocks its slot if confirmed, or pending and younger than the 15-minute hold. */
    public static final String ACTIVE =
        "(status='CONFIRMED' OR (status='PENDING' AND created_at >= (NOW() - INTERVAL 15 MINUTE)))";

    private static final Properties P = new Properties();

    static {
        try (InputStream in = DB.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) P.load(in);
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private static String prop(String key, String env) {
        String v = System.getenv(env);
        return v != null ? v : P.getProperty(key);
    }

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(prop("db.url", "DB_URL"),
                prop("db.user", "DB_USER"), prop("db.password", "DB_PASSWORD"));
    }

    private DB() {}
}
