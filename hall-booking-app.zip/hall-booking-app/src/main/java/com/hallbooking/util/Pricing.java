package com.hallbooking.util;

import java.time.*;

/** Dynamic pricing: hourly rate x hours, +20% on weekends, minus coupon. */
public final class Pricing {
    public record Quote(double hours, double base, double surcharge, double discount, double total) {}

    private static double r(double v) { return Math.round(v * 100.0) / 100.0; }

    public static Quote compute(double pricePerHour, LocalTime s, LocalTime e, LocalDate d, int percentOff) {
        double hours = Duration.between(s, e).toMinutes() / 60.0;
        if (hours < 2 || hours > 12) throw new IllegalArgumentException("Booking must be between 2 and 12 hours");
        double base = r(pricePerHour * hours);
        boolean weekend = d.getDayOfWeek() == DayOfWeek.SATURDAY || d.getDayOfWeek() == DayOfWeek.SUNDAY;
        double sur = weekend ? r(base * 0.20) : 0;
        double disc = r((base + sur) * percentOff / 100.0);
        return new Quote(hours, base, sur, disc, r(base + sur - disc));
    }

    private Pricing() {}
}
