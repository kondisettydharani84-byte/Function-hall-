package com.hallbooking.servlet;

import com.google.gson.JsonObject;
import com.hallbooking.util.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.time.YearMonth;
import java.util.Map;
import java.util.UUID;

/**
 * Demo payment gateway. Methods: CARD, UPI, NETBANKING, VENUE (pay at venue).
 * Card number and CVV are validated and then discarded; only the last 4 digits are stored.
 * Demo cards: 4242 4242 4242 4242 succeeds, any card ending 0002 is declined.
 * For real money, replace simulateGateway() with Razorpay / Stripe / PayPal.
 */
@WebServlet("/api/pay")
public class PaymentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Integer uid = Json.userId(req);
        if (uid == null) { Json.error(res, 401, "Please log in"); return; }
        try {
            JsonObject b = Json.body(req);
            int bookingId = b.get("bookingId").getAsInt();
            String method = Json.str(b, "method");
            String last4 = null;

            switch (method) {
                case "CARD" -> {
                    String num = Json.str(b, "cardNumber").replaceAll("[\\s-]", "");
                    if (!num.matches("\\d{13,19}") || !luhn(num)) { Json.error(res, 400, "Invalid card number"); return; }
                    if (!validExpiry(Json.str(b, "expiry"))) { Json.error(res, 400, "Card expiry is invalid or in the past (MM/YY)"); return; }
                    if (!Json.str(b, "cvv").matches("\\d{3,4}")) { Json.error(res, 400, "Invalid CVV"); return; }
                    if (num.endsWith("0002")) { Json.error(res, 402, "Card declined by the bank. Try another card."); return; }
                    last4 = num.substring(num.length() - 4);
                }
                case "UPI" -> {
                    if (!Json.str(b, "upiId").matches("[\\w.\\-]{2,}@[a-zA-Z]{2,}")) { Json.error(res, 400, "Enter a valid UPI ID like name@bank"); return; }
                }
                case "NETBANKING" -> {
                    if (Json.str(b, "bank").isEmpty()) { Json.error(res, 400, "Choose your bank"); return; }
                }
                case "VENUE" -> { }
                default -> { Json.error(res, 400, "Unknown payment method"); return; }
            }

            try (Connection c = DB.get()) {
                c.setAutoCommit(false);
                try {
                    double amount;
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT total_amount,status,(created_at < (NOW() - INTERVAL 15 MINUTE)) expired FROM bookings WHERE id=? AND user_id=? FOR UPDATE")) {
                        ps.setInt(1, bookingId); ps.setInt(2, uid);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) { Json.error(res, 404, "Booking not found"); return; }
                            if (!"PENDING".equals(rs.getString("status"))) { Json.error(res, 409, "This booking is not awaiting payment"); return; }
                            if (rs.getBoolean("expired")) { c.rollback(); Json.error(res, 410, "The 15-minute hold expired. Please book again."); return; }
                            amount = rs.getDouble("total_amount");
                        }
                    }
                    String txn = "TXN" + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
                    String status = method.equals("VENUE") ? "PAY_AT_VENUE" : "SUCCESS";
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO payments(booking_id,method,amount,status,txn_id,card_last4) VALUES(?,?,?,?,?,?)")) {
                        ps.setInt(1, bookingId); ps.setString(2, method); ps.setDouble(3, amount);
                        ps.setString(4, status); ps.setString(5, txn); ps.setString(6, last4);
                        ps.executeUpdate();
                    }
                    try (PreparedStatement ps = c.prepareStatement("UPDATE bookings SET status='CONFIRMED' WHERE id=?")) {
                        ps.setInt(1, bookingId);
                        ps.executeUpdate();
                    }
                    c.commit();
                    Json.send(res, 200, Map.of("ok", true, "txn", txn, "status", status, "amount", amount));
                } catch (Exception e) {
                    c.rollback();
                    throw e;
                }
            }
        } catch (Exception e) {
            Json.error(res, 400, "Payment could not be processed");
        }
    }

    private static boolean luhn(String n) {
        int sum = 0; boolean alt = false;
        for (int i = n.length() - 1; i >= 0; i--) {
            int d = n.charAt(i) - '0';
            if (alt && (d *= 2) > 9) d -= 9;
            sum += d; alt = !alt;
        }
        return sum % 10 == 0;
    }

    private static boolean validExpiry(String e) {
        if (!e.matches("(0[1-9]|1[0-2])/\\d{2}")) return false;
        YearMonth ym = YearMonth.of(2000 + Integer.parseInt(e.substring(3)), Integer.parseInt(e.substring(0, 2)));
        return !ym.isBefore(YearMonth.now());
    }
}
