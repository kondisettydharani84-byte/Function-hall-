package com.hallbooking.servlet;

import com.google.gson.JsonObject;
import com.hallbooking.util.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.security.SecureRandom;
import java.sql.*;
import java.time.*;
import java.util.*;

@WebServlet("/api/bookings/*")
public class BookingServlet extends HttpServlet {
    private static final String CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final SecureRandom RND = new SecureRandom();

    /** My bookings. */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Integer uid = Json.userId(req);
        if (uid == null) { Json.error(res, 401, "Please log in"); return; }
        String sql = "SELECT b.id,b.ref_code,h.name hall,h.emoji,b.event_date,b.start_time,b.end_time,b.guests,b.event_type,"
                + "b.total_amount,b.status,(b.status='PENDING' AND b.created_at < (NOW() - INTERVAL 15 MINUTE)) expired,"
                + "GREATEST(0, 900 - TIMESTAMPDIFF(SECOND, b.created_at, NOW())) hold_left,"
                + "(SELECT p.method FROM payments p WHERE p.booking_id=b.id ORDER BY p.id DESC LIMIT 1) method,"
                + "(SELECT p.txn_id FROM payments p WHERE p.booking_id=b.id ORDER BY p.id DESC LIMIT 1) txn "
                + "FROM bookings b JOIN halls h ON h.id=b.hall_id WHERE b.user_id=? ORDER BY b.event_date DESC,b.start_time DESC";
        try (Connection c = DB.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, uid);
            List<Map<String, Object>> out = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("id", rs.getInt("id")); m.put("ref", rs.getString("ref_code"));
                    m.put("hall", rs.getString("hall")); m.put("emoji", rs.getString("emoji"));
                    m.put("date", rs.getString("event_date"));
                    m.put("start", rs.getString("start_time").substring(0, 5)); m.put("end", rs.getString("end_time").substring(0, 5));
                    m.put("guests", rs.getInt("guests")); m.put("eventType", rs.getString("event_type"));
                    m.put("total", rs.getDouble("total_amount")); m.put("holdLeft", rs.getInt("hold_left"));
                    m.put("status", rs.getBoolean("expired") ? "EXPIRED" : rs.getString("status"));
                    m.put("method", rs.getString("method")); m.put("txn", rs.getString("txn"));
                    out.add(m);
                }
            }
            Json.send(res, 200, out);
        } catch (Exception e) {
            Json.error(res, 500, "Could not load bookings");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String path = req.getPathInfo() == null ? "/" : req.getPathInfo();
        try {
            JsonObject b = Json.body(req);
            switch (path) {
                case "/quote" -> quoteOnly(b, res);
                case "/cancel" -> cancel(req, b, res);
                default -> create(req, b, res);
            }
        } catch (IllegalArgumentException | java.time.DateTimeException | NullPointerException | IllegalStateException | ClassCastException e) {
            Json.error(res, 400, e instanceof IllegalArgumentException && e.getMessage() != null ? e.getMessage() : "Please check the form values");
        } catch (Exception e) {
            Json.error(res, 500, "Server error");
        }
    }

    private record Priced(Pricing.Quote q, String coupon, LocalDate date, LocalTime start, LocalTime end) {}

    /** Validates the request and prices it. Throws IllegalArgumentException with a friendly message. */
    private Priced price(Connection c, JsonObject b) throws SQLException {
        LocalDate date = LocalDate.parse(Json.str(b, "date"));
        LocalTime s = LocalTime.parse(Json.str(b, "start")), e = LocalTime.parse(Json.str(b, "end"));
        if (date.isBefore(LocalDate.now())) throw new IllegalArgumentException("Date is in the past");
        if (!s.isBefore(e)) throw new IllegalArgumentException("End time must be after start time");
        if (s.isBefore(LocalTime.of(6, 0)) || e.isAfter(LocalTime.of(23, 0))) throw new IllegalArgumentException("Halls are open 06:00 to 23:00");
        double pph;
        try (PreparedStatement ps = c.prepareStatement("SELECT price_per_hour FROM halls WHERE id=?")) {
            ps.setInt(1, b.get("hallId").getAsInt());
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new IllegalArgumentException("Hall not found");
                pph = rs.getDouble(1);
            }
        }
        String coupon = Json.str(b, "coupon").toUpperCase();
        int off = 0;
        if (!coupon.isEmpty()) {
            try (PreparedStatement ps = c.prepareStatement("SELECT percent_off FROM coupons WHERE code=? AND active=1")) {
                ps.setString(1, coupon);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new IllegalArgumentException("Invalid coupon code");
                    off = rs.getInt(1);
                }
            }
        }
        return new Priced(Pricing.compute(pph, s, e, date, off), coupon, date, s, e);
    }

    private void quoteOnly(JsonObject b, HttpServletResponse res) throws Exception {
        try (Connection c = DB.get()) {
            Json.send(res, 200, price(c, b).q());
        }
    }

    private void create(HttpServletRequest req, JsonObject b, HttpServletResponse res) throws Exception {
        Integer uid = Json.userId(req);
        if (uid == null) { Json.error(res, 401, "Please log in to book"); return; }
        int hallId = b.get("hallId").getAsInt(), guests = b.get("guests").getAsInt();
        String type = Json.str(b, "eventType");
        if (type.isEmpty() || type.length() > 40) throw new IllegalArgumentException("Choose an event type");

        try (Connection c = DB.get()) {
            c.setAutoCommit(false);
            try {
                int capacity;
                // Lock the hall row so two people cannot book the same slot at the same time.
                try (PreparedStatement ps = c.prepareStatement("SELECT capacity FROM halls WHERE id=? FOR UPDATE")) {
                    ps.setInt(1, hallId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new IllegalArgumentException("Hall not found");
                        capacity = rs.getInt(1);
                    }
                }
                if (guests < 1 || guests > capacity) throw new IllegalArgumentException("Guests must be between 1 and " + capacity);
                Priced p = price(c, b);

                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT COUNT(*) FROM bookings WHERE hall_id=? AND event_date=? AND " + DB.ACTIVE + " AND start_time<? AND end_time>?")) {
                    ps.setInt(1, hallId); ps.setDate(2, java.sql.Date.valueOf(p.date()));
                    ps.setTime(3, Time.valueOf(p.end())); ps.setTime(4, Time.valueOf(p.start()));
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) > 0) { c.rollback(); Json.error(res, 409, "Sorry, that time slot is already taken"); return; }
                    }
                }

                String ref = "HB-" + randomCode(6);
                int id;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO bookings(ref_code,user_id,hall_id,event_date,start_time,end_time,guests,event_type,coupon_code,total_amount) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, ref); ps.setInt(2, uid); ps.setInt(3, hallId);
                    ps.setDate(4, java.sql.Date.valueOf(p.date()));
                    ps.setTime(5, Time.valueOf(p.start())); ps.setTime(6, Time.valueOf(p.end()));
                    ps.setInt(7, guests); ps.setString(8, type);
                    ps.setString(9, p.coupon().isEmpty() ? null : p.coupon());
                    ps.setDouble(10, p.q().total());
                    ps.executeUpdate();
                    try (ResultSet k = ps.getGeneratedKeys()) { k.next(); id = k.getInt(1); }
                }
                c.commit();
                Json.send(res, 201, Map.of("bookingId", id, "ref", ref, "quote", p.q()));
            } catch (Exception e) {
                c.rollback();
                throw e;
            }
        }
    }

    private void cancel(HttpServletRequest req, JsonObject b, HttpServletResponse res) throws Exception {
        Integer uid = Json.userId(req);
        if (uid == null) { Json.error(res, 401, "Please log in"); return; }
        int id = b.get("bookingId").getAsInt();
        try (Connection c = DB.get()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE bookings SET status='CANCELLED' WHERE id=? AND user_id=? AND status IN ('PENDING','CONFIRMED') AND event_date>CURDATE()")) {
                ps.setInt(1, id); ps.setInt(2, uid);
                if (ps.executeUpdate() == 0) { c.rollback(); Json.error(res, 409, "This booking cannot be cancelled"); return; }
            }
            try (PreparedStatement ps = c.prepareStatement("UPDATE payments SET status='REFUNDED' WHERE booking_id=? AND status='SUCCESS'")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }
            c.commit();
            Json.send(res, 200, Map.of("ok", true));
        }
    }

    private static String randomCode(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(CHARS.charAt(RND.nextInt(CHARS.length())));
        return sb.toString();
    }
}
