CREATE DATABASE IF NOT EXISTS hallbooking;
USE hallbooking;

CREATE TABLE halls (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  emoji VARCHAR(8) DEFAULT '🏛️',
  capacity INT NOT NULL,
  base_price DECIMAL(10,2) NOT NULL,
  description VARCHAR(255)
);

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(12) NOT NULL UNIQUE,
  hall_id INT NOT NULL,
  customer_name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL,
  event_date DATE NOT NULL,
  slot ENUM('MORNING','EVENING','FULLDAY') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  status ENUM('CONFIRMED','PENDING_PAYMENT','CANCELLED') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hall_id) REFERENCES halls(id),
  INDEX idx_lookup (hall_id, event_date)
);

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  method ENUM('CARD','UPI','CASH') NOT NULL,
  txn_ref VARCHAR(20) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  status ENUM('PAID','PENDING','REFUNDED') NOT NULL,
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

CREATE TABLE promo_codes (
  code VARCHAR(20) PRIMARY KEY,
  percent_off INT NOT NULL
);

INSERT INTO halls (name, emoji, capacity, base_price, description) VALUES
('Royal Grand Hall','👑',500,45000,'Chandeliers, stage and full catering kitchen'),
('Garden Pavilion','🌿',250,28000,'Open-air lawn with covered dining area'),
('Skyline Terrace','🌇',120,18000,'Rooftop hall with city view and lounge'),
('Boardroom Suite','💼',40,6000,'AC conference room with projector');

INSERT INTO promo_codes VALUES ('WELCOME10',10),('FEST20',20);
