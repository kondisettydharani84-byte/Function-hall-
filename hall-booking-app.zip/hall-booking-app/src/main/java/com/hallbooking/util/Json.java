package com.hallbooking.util;

import com.google.gson.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.Map;

public final class Json {
    private static final Gson G = new Gson();

    public static void send(HttpServletResponse r, int status, Object o) throws IOException {
        r.setStatus(status);
        r.setContentType("application/json");
        r.setCharacterEncoding("UTF-8");
        r.getWriter().write(G.toJson(o));
    }

    public static void error(HttpServletResponse r, int status, String msg) throws IOException {
        send(r, status, Map.of("error", msg));
    }

    public static JsonObject body(HttpServletRequest req) throws IOException {
        try (BufferedReader br = req.getReader()) {
            return JsonParser.parseReader(br).getAsJsonObject();
        }
    }

    public static String str(JsonObject o, String key) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString().trim() : "";
    }

    /** Logged-in user id from session, or null. */
    public static Integer userId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return s == null ? null : (Integer) s.getAttribute("uid");
    }

    private Json() {}
}
