package com.hallbooking;

import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;

/** REST-style API: GET /api/halls, POST /api/book, GET /api/booking, POST /api/cancel */
@WebServlet("/api/*")
public class ApiServlet extends HttpServlet {
    private static final Gson G = new Gson();

    static class BookReq {
        int hallId; String name, email, date, slot, method, promo, payRef;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String p = String.valueOf(req.getPathInfo());
        try (Connection c = DB.get()) {
            if (p.equals("/halls")) halls(req, res, c);
            else if (p.equals("/booking")) lookup(req, res, c);
            else send(res, 404, Map.of("error", "Not found"));
        } catch (Exception e) { send(res, 500, Map.of("error", e.getMessage())); }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String p = String.valueOf(req.getPathInfo());
        try (Connection c = DB.get()) {
            if (p.equals("/book")) book(req, res, c);
            else if (p.equals("/cancel")) cancel(req, res, c);
            else send(res, 404, Map.of("error", "Not found"));
        } catch (Exception e) { send(res, 500, Map.of("error", e.getMessage())); }
    }

    // ---------- halls with availability + live price ----------
    private void halls(HttpServletRequest req, HttpServletResponse res, Connection c) throws Exception {
        String date = req.getParameter("date"), slot = req.getParameter("slot");
        int off = promoPercent(c, req.getParameter("promo"));
        List<Map<String, Object>> out = new ArrayList<>();
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM halls")) {
            while (rs.next()) {
                Map<String, Object> h = new LinkedHashMap<>();
                int id = rs.getInt("id");
                h.put("id", id); h.put("name", rs.getString("name")); h.put("emoji", rs.getString("emoji"));
                h.put("capacity", rs.getInt("capacity")); h.put("description", rs.getString("description"));
                h.put("basePrice", rs.getDouble("base_price"));
                if (date != null && !date.isEmpty() && slot != null) {
                    h.put("available", !conflict(c, id, date, slot, false));
                    h.put("total", price(rs.getDouble("base_price"), slot, date, off));
                }
                out.add(h);
            }
        }
        send(res, 200, Map.of("halls", out, "promoPercent", off));
    }

    // ---------- booking + payment in ONE transaction ----------
    private void book(HttpServletRequest req, HttpServletResponse res, Connection c) throws Exception {
        BookReq b = G.fromJson(req.getReader(), BookReq.class);
        if (b == null || b.name == null || b.name.isBlank() || b.email == null || !b.email.contains("@")
                || b.date == null || LocalDate.parse(b.date).isBefore(LocalDate.now()))
            { send(res, 400, Map.of("error", "Please fill valid name, email and a future date.")); return; }

        String payErr = validatePayment(b);
        if (payErr != null) { send(res, 400, Map.of("error", payErr)); return; }

        c.setAutoCommit(false);
        try {
            if (conflict(c, b.hallId, b.date, b.slot, true)) {
                c.rollback();
                send(res, 409, Map.of("error", "Sorry, that hall was just booked for this date/slot.")); return;
            }
            double base;
            try (PreparedStatement ps = c.prepareStatement("SELECT base_price FROM halls WHERE id=?")) {
                ps.setInt(1, b.hallId);
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) { c.rollback(); send(res, 404, Map.of("error", "Hall not found")); return; }
                base = rs.getDouble(1);
            }
            double amount = price(base, b.slot, b.date, promoPercent(c, b.promo));
            boolean cash = "CASH".equals(b.method);
            String code = "HB" + (100000 + new Random().nextInt(900000));
            int bookingId;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO bookings(code,hall_id,customer_name,email,event_date,slot,amount,status) VALUES(?,?,?,?,?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, code); ps.setInt(2, b.hallId); ps.setString(3, b.name.trim());
                ps.setString(4, b.email.trim()); ps.setDate(5, java.sql.Date.valueOf(b.date));
                ps.setString(6, b.slot); ps.setDouble(7, amount);
                ps.setString(8, cash ? "PENDING_PAYMENT" : "CONFIRMED");
                ps.executeUpdate();
                ResultSet k = ps.getGeneratedKeys(); k.next(); bookingId = k.getInt(1);
            }
            String txn = "TXN" + System.currentTimeMillis() % 100000000L;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO payments(booking_id,method,txn_ref,amount,status) VALUES(?,?,?,?,?)")) {
                ps.setInt(1, bookingId); ps.setString(2, b.method); ps.setString(3, txn);
                ps.setDouble(4, amount); ps.setString(5, cash ? "PENDING" : "PAID");
                ps.executeUpdate();
            }
            c.commit();
            send(res, 200, Map.of("code", code, "amount", amount, "txn", txn,
                    "status", cash ? "PENDING_PAYMENT" : "CONFIRMED"));
        } catch (Exception e) { c.rollback(); throw e; }
    }

    /** Demo payment gateway: card (Luhn check) / UPI (id format) / cash at venue. Card numbers are never stored. */
    private String validatePayment(BookReq b) {
        if (b.method == null) return "Choose a payment method.";
        switch (b.method) {
            case "CARD":
                String n = b.payRef == null ? "" : b.payRef.replaceAll("\\s", "");
                return n.matches("\\d{16}") && luhn(n) ? null : "Invalid card number.";
            case "UPI":
                return b.payRef != null && b.payRef.matches("[\\w.\\-]+@[\\w]+") ? null : "Invalid UPI ID (e.g. name@bank).";
            case "CASH": return null;
            default: return "Unknown payment method.";
        }
    }

    private boolean luhn(String n) {
        int sum = 0; boolean alt = false;
        for (int i = n.length() - 1; i >= 0; i--) {
            int d = n.charAt(i) - '0';
            if (alt && (d *= 2) > 9) d -= 9;
            sum += d; alt = !alt;
        }
        return sum % 10 == 0;
    }

    // ---------- lookup & cancel ----------
    private void lookup(HttpServletRequest req, HttpServletResponse res, Connection c) throws Exception {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT b.code,b.customer_name,b.event_date,b.slot,b.amount,b.status,h.name hall,p.method,p.status pay " +
                "FROM bookings b JOIN halls h ON h.id=b.hall_id JOIN payments p ON p.booking_id=b.id WHERE b.code=?")) {
            ps.setString(1, req.getParameter("code"));
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) { send(res, 404, Map.of("error", "No booking with that code.")); return; }
            Map<String, Object> m = new LinkedHashMap<>();
            for (String k : new String[]{"code", "customer_name", "event_date", "slot", "amount", "status", "hall", "method", "pay"})
                m.put(k, rs.getString(k));
            send(res, 200, m);
        }
    }

    private void cancel(HttpServletRequest req, HttpServletResponse res, Connection c) throws Exception {
        String code = req.getParameter("code");
        c.setAutoCommit(false);
        try (PreparedStatement a = c.prepareStatement("UPDATE bookings SET status='CANCELLED' WHERE code=? AND status<>'CANCELLED'");
             PreparedStatement p = c.prepareStatement("UPDATE payments SET status=IF(status='PAID','REFUNDED',status) " +
                     "WHERE booking_id=(SELECT id FROM bookings WHERE code=?)")) {
            a.setString(1, code);
            if (a.executeUpdate() == 0) { c.rollback(); send(res, 404, Map.of("error", "Nothing to cancel.")); return; }
            p.setString(1, code); p.executeUpdate();
            c.commit();
            send(res, 200, Map.of("ok", true));
        } catch (Exception e) { c.rollback(); throw e; }
    }

    // ---------- helpers ----------
    /** A FULLDAY booking blocks every slot; any booking blocks a FULLDAY request. */
    private boolean conflict(Connection c, int hall, String date, String slot, boolean lock) throws SQLException {
        String sql = "SELECT 1 FROM bookings WHERE hall_id=? AND event_date=? AND status<>'CANCELLED' " +
                "AND (slot=? OR slot='FULLDAY' OR ?='FULLDAY')" + (lock ? " FOR UPDATE" : "");
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, hall); ps.setDate(2, java.sql.Date.valueOf(date)); ps.setString(3, slot); ps.setString(4, slot);
            return ps.executeQuery().next();
        }
    }

    /** Dynamic pricing: full day x1.8, weekend +20%, then promo discount. */
    private double price(double base, String slot, String date, int off) {
        double p = base * ("FULLDAY".equals(slot) ? 1.8 : 1.0);
        DayOfWeek d = LocalDate.parse(date).getDayOfWeek();
        if (d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY) p *= 1.2;
        return Math.round(p * (100 - off) / 100.0);
    }

    private int promoPercent(Connection c, String code) throws SQLException {
        if (code == null || code.isBlank()) return 0;
        try (PreparedStatement ps = c.prepareStatement("SELECT percent_off FROM promo_codes WHERE code=?")) {
            ps.setString(1, code.trim().toUpperCase());
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private void send(HttpServletResponse res, int status, Object body) throws IOException {
        res.setStatus(status);
        res.setContentType("application/json;charset=UTF-8");
        res.getWriter().write(G.toJson(body));
    }
}
