# 🏛️ Hall Booking System

Online hall booking with **HTML/JS front end**, **Java Servlet + JDBC back end**, and **MySQL** database.

## Features
- Live availability by date and slot (Morning / Evening / Full day)
- Double-booking protection (transactional `SELECT ... FOR UPDATE`)
- Dynamic pricing: weekend +20%, full day x1.8, promo codes (`WELCOME10`, `FEST20`)
- Payment methods: Card (Luhn check), UPI, Pay at venue. Card numbers are never stored
- Booking code lookup and cancellation with automatic payment refund status

## Structure
```
hall-booking/
├── pom.xml
├── sql/schema.sql
└── src/main
    ├── java/com/hallbooking/{DB.java, ApiServlet.java}
    └── webapp/index.html
```

## Run
1. Import the schema: `mysql -u root -p < sql/schema.sql`
2. Set DB credentials if needed: `DB_URL`, `DB_USER`, `DB_PASS` environment variables
3. Build: `mvn clean package`
4. Copy `target/hall-booking.war` into **Tomcat 10+** `webapps/` and open `http://localhost:8080/hall-booking/`

## Note
Payment is a demo simulation. For real payments, integrate a gateway (Razorpay, Stripe) in `validatePayment`.
